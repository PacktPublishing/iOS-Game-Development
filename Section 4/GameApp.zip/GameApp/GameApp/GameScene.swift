//
//  GameScene.swift
//  GameApp
//
//  Created by deeodus on 23/05/2018.
//  Copyright © 2018 deeodus. All rights reserved.
//

import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate{
    
    let catNode = SKSpriteNode(imageNamed: "cat")
    let bgNode = SKSpriteNode(imageNamed: "bg")
    var timer = Timer()
    var gameTime = 0
    
    override func didMove(to view: SKView) {

        physicsWorld.contactDelegate = self
        
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(addBall), userInfo: nil, repeats: true)
        
        addCat()
        //addBackground()

    }
    
    @objc func addBall(){
        
        gameTime += 1
        
        let randomX = arc4random_uniform(UInt32(self.size.width))
        
        let ball = SKSpriteNode(imageNamed: "red-ball")
        ball.position.y = self.size.height
        ball.position.x = CGFloat(randomX)
        
        ball.setScale(0.3)
        
        ball.physicsBody = SKPhysicsBody(circleOfRadius: ball.size.width/2 + 5)
        
        ball.physicsBody?.contactTestBitMask = (ball.physicsBody?.collisionBitMask)!
        ball.name = "ball"
        addChild(ball)
        
        let moveAction = SKAction.moveTo(y: 0, duration: 5)
        
        let deleteAction = SKAction.removeFromParent()
        
        ball.run(SKAction.sequence([moveAction, deleteAction]))
        
        if gameTime > 10{
            
            timer.invalidate()
            presentGameOverScene()
        }
    }
    
    func presentGameOverScene(){
        
        let gameOverScene = GameOverScene(size: self.size)
        let transition = SKTransition.doorsOpenVertical(withDuration: 1.5)
        self.view?.presentScene(gameOverScene, transition: transition)
    }
    
    func addCat(){
        
        catNode.position = CGPoint(x: catNode.size.width/2, y: catNode.size.height/2)
        catNode.setScale(0.8)
        catNode.zPosition = 1
        catNode.physicsBody = SKPhysicsBody(rectangleOf: catNode.size)
        catNode.physicsBody?.affectedByGravity = false
        catNode.physicsBody?.isDynamic = false
        catNode.name = "cat"
        addChild(catNode)
    }
    
    func addBackground(){
        bgNode.anchorPoint = CGPoint.zero
        bgNode.zPosition = 0
        addChild(bgNode)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        if let location = touch?.location(in: self){
            
            catNode.position.x = location.x
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        guard let nodeA = contact.bodyA.node else { return }
        guard let nodeB = contact.bodyB.node else { return }
        
        if nodeA.name == "ball"{
            nodeA.removeFromParent()
        }else if nodeB.name == "ball"{
            nodeB.removeFromParent()
        }
    }
    
}







