//
//  GameScene.swift
//  GameApp
//
//  Created by deeodus on 23/05/2018.
//  Copyright © 2018 deeodus. All rights reserved.
//

import SpriteKit
import AVFoundation

class GameScene: SKScene, SKPhysicsContactDelegate{
    
    var audioPlayer = AVAudioPlayer()
    var gameSoundURL: URL?
    
    var musicPlayer = AVAudioPlayer()
    var musicURL: URL?
    
    let catNode = SKSpriteNode(imageNamed: "cat")
    let bgNode = SKSpriteNode(imageNamed: "bg")
    let scoreLabel = SKLabelNode(text: "0")
    let liveLabel = SKLabelNode(text: "3")
    let playSoundNode = SKSpriteNode(imageNamed: "play")
    let stopSoundNode = SKSpriteNode(imageNamed: "stop")
    
    var timer = Timer()
    var scores = 0
    var lives = 3
    
    override func didMove(to view: SKView) {

        physicsWorld.contactDelegate = self
        
        gameSoundURL = Bundle.main.url(forResource: "sound", withExtension: "mp3")
        musicURL = Bundle.main.url(forResource: "music", withExtension: "mp3")
        
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(addBall), userInfo: nil, repeats: true)
        
        addCat()
        //addBackground()
        addScoreLabel()
        initSound()
        //initMusic()
        addSoundNode()
        addLivesLabel()
    }
    
    func initSound(){
        
        guard let url = gameSoundURL else { return }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
        }catch{
            print("error")
        }
        audioPlayer.numberOfLoops = 1
        audioPlayer.prepareToPlay()
        
    }
    
    func initMusic(){
        
        guard let url = musicURL else { return }
        
        do {
            musicPlayer = try AVAudioPlayer(contentsOf: url)
        }catch{
            print("error")
        }
        musicPlayer.numberOfLoops = -1
        musicPlayer.prepareToPlay()
        musicPlayer.play()
    }
    
    func addLivesLabel(){
        liveLabel.position = CGPoint(x: 10, y: 5)
        addChild(liveLabel)
    }
    
    func addSoundNode(){
        
        playSoundNode.anchorPoint = CGPoint.zero
        playSoundNode.position = CGPoint(x: 0, y: self.size.height - playSoundNode.size.height)
        playSoundNode.zPosition = 4
        addChild(playSoundNode)
        
        stopSoundNode.anchorPoint = CGPoint.zero
        stopSoundNode.position = CGPoint(x: 0, y: self.size.height - stopSoundNode.size.height)
        stopSoundNode.zPosition = 5
        addChild(stopSoundNode)
    }
    
    func addScoreLabel(){
        scoreLabel.fontColor = .white
        scoreLabel.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        addChild(scoreLabel)
    }
    
    
    @objc func addBall(){
        
        let randomNumber = arc4random_uniform(UInt32(2))
        let randomX = arc4random_uniform(UInt32(self.size.width))
        
        var ball = SKSpriteNode()
        
        if randomNumber == 0{
            ball = SKSpriteNode(imageNamed: "red-ball")
            ball.name = "ball"
        }else{
            ball = SKSpriteNode(imageNamed: "dangerball")
            ball.name = "dangerball"
        }
        
        ball.position.y = self.size.height
        ball.position.x = CGFloat(randomX)
        
        ball.setScale(0.3)
        
        ball.physicsBody = SKPhysicsBody(circleOfRadius: ball.size.width/2 + 5)
        
        ball.physicsBody?.contactTestBitMask = (ball.physicsBody?.collisionBitMask)!
        addChild(ball)
        
        let moveAction = SKAction.moveTo(y: 0, duration: 5)
        
        let deleteAction = SKAction.removeFromParent()
        
        ball.run(SKAction.sequence([moveAction, deleteAction]))
        
    }
    
    func addBlink(node: SKSpriteNode){
        
        let fadeAction = SKAction.sequence([SKAction.fadeAlpha(to: 0.1, duration: 0.1), SKAction.fadeAlpha(to: 1.0, duration: 0.1)])
        
        let repeatAction = SKAction.repeat(fadeAction, count: 10)
        
        node.run(repeatAction)
    }
    
    func presentGameOverScene(){
        
        let gameOverScene = GameOverScene(size: self.size)
        let transition = SKTransition.doorsOpenVertical(withDuration: 1.5)
        self.view?.presentScene(gameOverScene, transition: transition)
    }
    
    func addCat(){
        
        catNode.position = CGPoint(x: catNode.size.width/2, y: catNode.size.height/2)
        catNode.setScale(0.8)
        catNode.zPosition = 1
        catNode.physicsBody = SKPhysicsBody(rectangleOf: catNode.size)
        catNode.physicsBody?.affectedByGravity = false
        catNode.physicsBody?.isDynamic = false
        catNode.name = "cat"
        addChild(catNode)
    }
    
    func addBackground(){
        bgNode.anchorPoint = CGPoint.zero
        bgNode.zPosition = 0
        addChild(bgNode)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        if let location = touch?.location(in: self){
            
            catNode.position.x = location.x
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        audioPlayer.play()
        
        guard let nodeA = contact.bodyA.node else { return }
        guard let nodeB = contact.bodyB.node else { return }
        
        if nodeA.name == "ball"{
            nodeA.removeFromParent()
            scores += 1
        }else if nodeB.name == "ball"{
            nodeB.removeFromParent()
            scores += 1
        }else if nodeA.name == "dangerball"{
            nodeB.removeFromParent()
            addBlink(node: catNode)
            lives -= 1
        }else if nodeB.name == "dangerball"{
            nodeB.removeFromParent()
            addBlink(node: catNode)
            lives -= 1
        }
        
        scoreLabel.text = "\(scores)"
        liveLabel.text = "\(lives)"
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let location = touches.first?.location(in: self){
            
            if atPoint(location) == stopSoundNode{
                
                stopSoundNode.zPosition = 4
                playSoundNode.zPosition = 5
                musicPlayer.pause()
            }else if atPoint(location) == playSoundNode{
                
                stopSoundNode.zPosition = 5
                playSoundNode.zPosition = 4
                musicPlayer.play()
            }
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        
        if lives == 0{
            
            endGame()
        }
        
        if let ball = self.childNode(withName: "ball") as? SKSpriteNode{
            
            if ball.position.y < 0{
                
                endGame()
            }
        }
        
        if let ball = self.childNode(withName: "dangerball") as? SKSpriteNode{
            
            if ball.position.y < 0{
                ball.removeFromParent()
            }
        }
    }
    
    func endGame(){
        
        UserDefaults.standard.set(scores, forKey: "scores")
        timer.invalidate()
        presentGameOverScene()
    }
}







