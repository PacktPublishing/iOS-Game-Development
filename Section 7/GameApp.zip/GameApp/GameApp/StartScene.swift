//
//  StartScene.swift
//  GameApp
//
//  Created by deeodus on 05/06/2018.
//  Copyright © 2018 deeodus. All rights reserved.
//

import SpriteKit

class StartScene: SKScene{
    
    let playButton = SKSpriteNode(imageNamed: "start")
    let catNode = SKSpriteNode(imageNamed: "cat")
    let squareNode = SKSpriteNode(imageNamed: "square")
    var texture = [SKTexture]()
    
    override func didMove(to view: SKView) {
        
        self.backgroundColor = SKColor.white
        
        for i in 1...12{
            texture.append(SKTexture(imageNamed: "\(i)"))
        }
        
        squareNode.anchorPoint = CGPoint(x: 0, y: 1)
        squareNode.position = CGPoint(x: 0, y: self.size.height/2)
        squareNode.size = CGSize(width: self.size.width, height: self.size.height/2)
        addChild(squareNode)
        
        catNode.position = CGPoint(x: self.size.width/2, y: self.size.height * 3/4)
        addChild(catNode)
        
        let animateAction = SKAction.animate(with: texture, timePerFrame: 0.1)
        catNode.run(SKAction.repeatForever(animateAction))
        
        playButton.setScale(0.5)
        playButton.position = CGPoint(x: self.size.width/2, y: self.size.height/4)
        addChild(playButton)
        
        addScoreLabel()
    }
    
    func addScoreLabel(){
        
        let scoreLabel = SKLabelNode()
        scoreLabel.fontSize = 30
        scoreLabel.position = CGPoint(x: self.size.width/2, y: self.size.height/2)
        scoreLabel.fontName = "Arial"
        scoreLabel.fontColor = .black
        addChild(scoreLabel)
        
        scoreLabel.text = "Last Score: \(UserDefaults.standard.integer(forKey: "scores"))"
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        if let location = touch?.location(in: self){
            
            if atPoint(location) == playButton{
                
                let gameScene = GameScene(size: self.size)
                let transition = SKTransition.doorsOpenVertical(withDuration: 1.5)
                self.view?.presentScene(gameScene, transition: transition)
            }
        }
    }
    
    
    
    
}
